package com.capstone.repository;

import com.capstone.entity.Member;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MemberRepository extends JpaRepository<Member, String> {
    Member findByUsername(String username);
    Member findByEmail(String email);
    boolean existsByUsername(String username);
    boolean existsByEmail(String email);
}
